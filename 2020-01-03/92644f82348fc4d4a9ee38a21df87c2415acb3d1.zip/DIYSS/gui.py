# -*- coding: utf-8 -*-
import sys
import time
from diysignal001 import Ui_MainWindow

# from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QMainWindow, QApplication
# from PyQt5.QtCore import QRegExp
# from PyQt5.QtGui import QRegExpValidator, QIntValidator, QDoubleValidator
from PyQt5.QtCore import QThread
from PyQt5.QtCore import pyqtSignal



class MyThread(QThread):
    returncode = pyqtSignal(int)

    def __init__(self):
        super(MyThread, self).__init__()
        self.threadalive = True

    def __del__(self):
        self.wait()

    def run(self):
        if self.run_test() == 0:
            print("Finished")
            return 0
        else:
            print("FAIL")
            return 255

    def stop(self):
        if not self.threadalive:
            self.quit()
            self.wait()

    def run_test(self):
        for i in range(0, 10):
            try:
                self.run_item(i)               
            except IOError:
                print("Failed item %s" % i)
                self.returncode.emit(255)
                self.threadalive = False

        self.returncode.emit(0)
        self.threadalive = False
        print("Finished")
        return 0

    def run_item(self, times):
        print(times)
        time.sleep(0.2)
        if times == 3:
            raise IOError


class TestGUI(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(TestGUI, self).__init__()
        self.setupUi(self)

        self.setWindowTitle("TestGUI11")
        self.lineEdit.setFocus()
        self.lineEdit.returnPressed.connect(self.linevalidator)
        self.lineEdit_2.returnPressed.connect(self.linevalidator)
        self.lineEdit.setPlaceholderText("TEXT 001")
        self.lineEdit_2.setPlaceholderText("TEXT 002")

        self.pushButton.clicked.connect(self.btn1Clicked)
        self.pushButton_2.clicked.connect(self.btn2Clicked)

    def linevalidator(self):
        sender = self.sender()
        evt = sender.text()
        if (len(evt)) == 0:
            print("Fail")

    def btn1Clicked(self):
        print("you press btn")
        self.lineEdit_2.setDisabled(True)
        self.lineEdit.setDisabled(True)
        self.pushButton.setDisabled(True)
        self.pushButton_2.setDisabled(True)

        self.threading = MyThread()
        self.threading.start()
        if self.threading != 0:
            print("Failed")
            
        # QApplication.processEvents

    def btn2Clicked(self):
        self.lineEdit.setText("")
        self.lineEdit_2.setText("")

    def returnPressed(self):
        sender = self.sender
        evt = sender.text()
        print(evt)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    ui = TestGUI()
    ui.show()
    sys.exit(app.exec_())